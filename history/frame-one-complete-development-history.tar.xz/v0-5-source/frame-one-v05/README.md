# Frame One v0.5 — cinematic beginner film school prototype

Use `frame-one-v05-open-in-browser.html` from the accompanying download as the easiest single-file version. The project folder is an optional installable-web-app source; to use manifest/service worker, serve it using HTTPS or localhost. **This is not a native Android APK.**

## Implemented now
- 13 structured beginner lessons with correct multiple-choice answer checks and 13 interactive creative choice experiments.
- Six-chapter learner journey, marking 20 **future** topics as planned; not all 33 lessons exist yet.
- Film history, screenwriting, acting, lighting, and editing additions in addition to eight earlier lessons.
- Four labs: Frame (3 illustrations plus side-by-side compare), Sound (original generated tone sketches), Light (3 simplified direction illustrations), Cut (three-shot reordering, adjustable 1–5 second durations, play/stop timed storyboard).
- Nine introductory film roles; 20 glossary terms with Telugu labels; short Telugu helpers for all 13 lessons.
- Local-only saved progress using the original `frameone-progress-v01` key. Previously finished chapters are preserved. No external assets or analytics.

## Important boundaries
- This is an illustration-based learning prototype, not a camera, light physics, or professional editing simulator.
- Browser visual and cross-device layout testing are not yet complete. No filmmaker sign-off or formal user testing.
- No film clips or copyrighted soundtracks used; images/scenes are original drawings.
- See `ROADMAP.md` and `CONTENT_ACCURACY_V05.md` for detailed scope, quality standard and sources.

## Test

`node test-runtime.cjs` checks lesson quizzes and links, content surface, local progress persistence, major interactive flows, and supported labs. JavaScript syntax can be checked by extracting the main `<script>` content and running `node --check`.

## Source structure
- `index.html` — application
- `icon-192.png`, `icon-512.png`, `manifest.webmanifest`, `sw.js` — optional PWA support
- `test-runtime.cjs` — runtime contracts
- `ROADMAP.md` — staged product and curriculum plan
- `CONTENT_ACCURACY_V05.md` — technical/editorial review notes
