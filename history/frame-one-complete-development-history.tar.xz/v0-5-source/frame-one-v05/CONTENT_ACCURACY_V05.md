# Frame One v0.5 — factual and educational content notes

**Content scope:** 13 beginner lessons, 13 creative decision prompts, 20 bilingual glossary labels, nine introductory occupations, frame/sound/cut/light labs. English lessons with *short* Telugu summaries, not full Telugu translations.

## Sources and safeguards

- **Cinema history:** British Film Institute, *In the beginning: cinema's murky origin story* (https://www.bfi.org.uk/sight-and-sound/features/origins-cinema-early-inventors-pioneers). A famous Lumière screening happened on 28 December 1895, but that was not the first moving-picture viewing or projection ever. Don't attribute cinema's invention to a single person/group.
- **Early motion pictures:** National Science and Media Museum, *The Lumière Brothers, Pioneers of Cinema and Photography* (https://blog.scienceandmediamuseum.org.uk/the-lumiere-brothers-pioneers-of-cinema-and-colour-photography/). Note that even well-known early film examples have variant versions.
- **Cut and continuity:** New York Film Academy, *A Beginner's Guide to Film Editing Vocabulary* (https://www.nyfa.edu/student-resources/a-beginners-guide-to-film-editing-vocabulary/). A cut is a direct edit from one shot to another; arrangement and duration are editing decisions.
- **Shot, scene, frame and take:** existing v0.4 internal notes and Columbia University film-language glossary. A still clock can draw attention to the time indicated, but cannot depict time passing by itself.
- **Lighting:** Current Light Lab is a simplified drawing of front, side, backlight differences, *not* a camera/physics simulator. Properties like softness depend on the apparent size of the light source, among other factors. No fixed emotional rule is asserted.
- **24 crafts:** Telugu-industry context; not a fixed worldwide list of precisely 24 film roles. Current role catalogue includes nine introductory departments/occupations, not the industry's official complete list.
- **Creative mini-activities:** Show two defensible possible choices, not a claim that one is the 'best' cinematic choice. All 13 objective quizzes have a defensible correct answer.
- **Audio sketch:** Synthesized original tones are not a full film soundtrack. No music is not the same as no other sound.

## Known limitations requiring further review

- English-to-Telugu helper summaries need review by a Telugu-native filmmaking instructor before public educational use.
- The storyboard illustration is not true cinematography simulation. Camera crop examples do not model focal length changes or changing camera-to-subject distance.
- Shot durations in Cut Lab use a timed original *still illustration* preview. This is useful for relative timing, but does not teach real video motion or shot performance.
- The editorial content is carefully reviewed for beginner accuracy but has **not** received independent filmmaker/educator sign-off.
- Full visual browser interaction testing was not possible due browser execution restrictions. Mobile and screen-reader testing remain necessary.
