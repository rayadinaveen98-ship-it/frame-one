const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const memory={};
function boot(){
 const events={}, el={content:{innerHTML:''},progressCircle:{style:{setProperty(){}}},progressLabel:{textContent:''}};
 const doc={getElementById:id=>el[id]||null,querySelectorAll:()=>[],querySelector:()=>({scrollIntoView(){}}),addEventListener:(type,fn)=>events[type]=fn};
 const ctx={document:doc,localStorage:{getItem:k=>memory[k]??null,setItem:(k,v)=>memory[k]=v},window:{addEventListener(){},scrollTo(){}},navigator:{},history:{replaceState(){},pushState(){}},location:{hash:'',protocol:'file:'},confirm:()=>true,console,Set,clearTimeout,setTimeout};
 vm.runInNewContext(script,ctx);
 function click(dataset={},id=''){events.click({target:{closest(){return {dataset,id}}}});return el.content.innerHTML;}
 return {el,click,events};
}
let {el,click,events}=boot();
assert(el.content.innerHTML.includes('Start your first lesson'),'home CTA');
assert(el.content.innerHTML.includes('SIX CHAPTER PATHS'),'home path');
assert(click({page:'learn'}).includes('Every great film starts with curiosity.'),'learn page');
assert(el.content.innerHTML.includes('Discover cinema'),'chapter path');
assert(el.content.innerHTML.includes('Film words, explained simply'),'glossary');
assert(el.content.innerHTML.includes('20 words'),'glossary count');
assert(el.content.innerHTML.includes('Future lessons planned'),'not falsely claiming planned lessons exist');
assert(click({lesson:'history'}).includes('28 December 1895'),'history lesson');
assert(el.content.innerHTML.includes('YOUR FIRST DIRECTOR'),'lesson activity');
assert(click({activity:'0'}).includes('everyday'),'creative choice feedback');
click({telugu:''});assert(el.content.innerHTML.includes('చిన్న వివరణ'),'Telugu helper for history');
const cases=[['why',1],['history',1],['units',0],['story',1],['script',1],['acting',1],['shot',1],['camera',1],['lighting',1],['sound',0],['editing',0],['crew',2],['making',1]];
for(const [id,n] of cases){click({lesson:id});assert.equal((el.content.innerHTML.match(/class="quiz-option /g)||[]).length,3,id);click({answer:String(n)});assert(el.content.innerHTML.includes('✓ Exactly.'),id);}
click({lesson:'why'});click({answer:'1'});click({complete:''});
assert.equal(el.progressLabel.textContent,'1/13 lessons');
({el,click,events}=boot());assert.equal(el.progressLabel.textContent,'1/13 lessons','progress compatible');
click({lesson:'units'});assert(click({openCut:'1'}).includes("You're editing the scene."));
assert(click({cutNext:''}).includes('Shot 2 of 3'));
assert(click({move:'1:left'}).includes('SHOT 01'));
assert(el.content.innerHTML.includes('WHAT THE FIRST SHOT MAY DO'));
assert(click({cutReset:''}).includes('8s TOTAL')===false); // reset 6s total
assert(el.content.innerHTML.includes('6s TOTAL'));
events.input({target:{id:'shotDuration',value:'5'}});events.change({target:{id:'shotDuration'}});
assert(el.content.innerHTML.includes('9s TOTAL'),'duration changed');
assert(click({cutPlay:'play'}).includes('Playing...'));click({cutPlay:'stop'});assert(!el.content.innerHTML.includes('Playing...'));
click({lab:'frame'});assert(el.content.innerHTML.includes('STORYBOARD · SHOT SIZE'));
assert(click({compare:''}).includes('REFERENCE · CLOSE-UP'));
assert(click({frame:'medium'}).includes('172 93 296 166.5'));
click({lab:'light'});assert(click({light:'side'}).includes('one side of the face brighter'));
click({lab:'sound'});assert(click({sound:'tension'}).includes('The picture we are imagining'));
click({page:'crafts'});assert(click({craft:'editing'}).includes('The editor chooses recorded shots'));
console.log('PASS: 13 quizzes, 13 creative decision activities, 6 chapters, Telugu and glossary, frame compare, cut timeline/reordering/timing/preview, sound/light, saved progress.');
