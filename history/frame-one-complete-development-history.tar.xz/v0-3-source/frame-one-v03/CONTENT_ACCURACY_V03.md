# Content and terminology review · v0.3

Review date: 2026-10-26

This is an editorial verification pass against selected publicly accessible educational sources, **not** a certificate of accuracy or an independent expert review.

## Newly added film words

- **Frame:** One image in a moving-image sequence. For beginners, the image visible when pausing a video.
- **Shot:** In a finished film, a continuous view before a change to another shot. In production, the word can also refer to a camera setup or uninterrupted recording. The glossary deliberately focuses on the *finished-film* meaning; both meanings should be introduced at a more advanced level.
- **Scene:** One connected unit or situation of story action. Multiple shots can form a scene. There are exceptions: experimental films and transitions between places and times make strict counting trickier.
- **Take:** One recorded attempt to perform or film a shot. The preferred take may be used in the edit, but not all recorded takes appear in the finished film.
- **Cut:** Here, an immediate edit from one shot to another. The same word can have other meanings on set (e.g., stop recording), which can be taught later.
- **Close-up and wide shot:** Terms describe *framing*, not a guaranteed emotion. A close-up emphasizes a subject/detail. A wide shot shows comparatively more surroundings.
- **Sound design:** A simplification focusing on sound effects and atmosphere. A complete film soundtrack also involves dialogue, music, and other specialist work, with role boundaries that vary by production.

## Cut Lab: claims and limits

The lab uses three flat, original illustrations of a bus-stop situation. It demonstrates that several *depicted* shot choices may be placed in one scene, and that changing the first shot may change what the viewer notices first. It is not a demonstration of moving actors, temporal continuity, real optical perspective, screen direction, real sound mixing or cinema editing software. A still clock **directs attention to time**, it does not itself show time passing. A silhouette does not show an actor's facial performance.

## Telugu support limits

The summaries are newly authored beginner explanations, not one-to-one translations of full lessons. Common English craft names have been included where appropriate. Terminology can vary among film professionals, industries, and communities. Further review by a Telugu-speaking film educator is advised.

## Sources consulted (not copied)

- University of West Georgia, *Glossary of Film Terms* — https://www.westga.edu/academics/university-college/writing/glossary_of_film_terms.php
- Film Education, *Glossary of film terminology* — https://www.filmeducation.org/resources/primary/teaching_with_film/film_in_primary_literacy/glossary_of_film_terminology/
- Columbia University, *Film Language Glossary — Take* — https://filmglossary.ccnmtl.columbia.edu/term/take/
- Columbia University, *Film Language Glossary — Close-up* — https://filmglossary.ccnmtl.columbia.edu/term/close-up/
- National Film and Sound Archive of Australia (via ASO), *Glossary* — https://aso.gov.au/about/glossary/
- Earlier v0.2 review: see project-provided `frame-one-v02-content-review.md` from the previous iteration.

## Still pending

Full professional filmmaking educator review, dedicated Telugu linguistic review, audience comprehension research, copyright counsel for eventual third-party clip usage, and actual browser/screen-reader device checks.
