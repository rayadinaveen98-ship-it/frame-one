# Frame One · v0.3

**Working title:** Frame One. **Project status:** original, offline-first beginner-filmmaking prototype, not an Android/iOS native app.

## Open and test

- **Fastest:** Open the separate `frame-one-v03-open-in-browser.html` file in a current desktop browser. This self-contained file has no internet or install requirements.
- **Full source:** Open `index.html` directly on a desktop browser. If local opening does not work, serve this folder with `python -m http.server 8000` and open `http://localhost:8000`.
- **Phone:** Put the full folder on an HTTPS static host for a shareable PWA experience; no hosting has been done yet. On some mobile browsers direct local HTML files are awkward or blocked.
- **Tests:** `node test-runtime.cjs`. Node.js 18+ recommended for tests only; the app itself needs no build tools.

## What's new in v0.3

1. **Cut Lab:** Original *still illustrations*, with three selectable shots from a single imagined bus-stop situation. Users can change the opening shot, browse the three images, and understand `shot`, `cut` and `scene` by comparison. It is **not video editing or actual filmed footage**.
2. **Telugu learning helpers:** Optional, simple Telugu summaries for **all eight lessons**. The full lesson, exercises and quizzes remain in English. The helper does **not** claim to be a full app-language translation. Film terms have an English name for easier recognition.
3. **Mini glossary:** Twelve common filmmaking terms, with English definitions and Telugu term labels. Expand it on the **Learn Cinema** screen.
4. **Contextual practice:** Frame, sound and editing lessons now lead straight to the relevant hands-on lab.
5. **Preserved v0.2 behavior:** 8 lessons and quizzes, 9 starter crafts, Frame Lab, Sound Lab and local progress storage. No signup, tracking or network requirement.
6. **Progress compatibility:** Existing completion data uses the same `frameone-progress-v01` key. Telugu preference has its own local key.

## What isn't in this release

- No real movie clips, footage, film scores, image uploads, AI grader, community, payment, cloud sync, native APK or iOS IPA.
- No claim that all Telugu terms are standard across all film industries. Users should learn common English terms, too.
- The scene lab uses simplified illustrations. Its three pictures are *examples of possible shot choices*; no sequence guarantees an emotion or interpretation.
- No film historian or teacher has signed off on a formal curriculum, and the current version was not visually QA'd in a live browser due to a blocked automated preview environment. Tests validate logic, not real display quality.

## Accuracy-first editorial policy

1. Explain concepts simply **without** changing their meaning.
2. Never claim a shot, editing cut, sound or camera angle has one guaranteed emotion.
3. Explain how a simulated illustration differs from filming with a real camera.
4. Use neutral, original instructional illustrations until properly licensed film examples are available.
5. Review terminology against credible educational glossaries; see `CONTENT_ACCURACY_V03.md`.
6. Get 5–10 beginners and an experienced film educator to review both understanding and terminology before public launch.

## Next proposed product stage

Conduct a small user-learning test and address usability issues. Only after that, consider a complete bilingual UI and more original scene demonstrations. Full mobile app development should follow successful learning validation.
