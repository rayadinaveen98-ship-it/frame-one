# v0.7 — Content and technical-accuracy review

## Scope of this version

New copy covers storyboard planning, shot/take distinctions, film departments across production phases, and optional practical notes. The original 13 lesson texts, quizzes, four labs and glossary remain as previously reviewed in development; independent film educator review is still **pending** for the entire curriculum.

## Film terminology applied carefully

- **Frame:** one still image from moving-image material; the original drawings are single **storyboard illustrations**.
- **Shot:** in an edited film, the uninterrupted image from one cut to the next; during filming, a shot can also mean a planned camera setup or filmed piece of action, depending on context.
- **Take:** one recorded attempt at performing/capturing a shot. A storyboard panel is neither a recorded take nor moving footage.
- **Story beat:** a useful structural idea (something changes or is learned), not a required formula. Three beats do not imply every film or scene must have exactly three shots.
- **Wide/medium/close-up:** labels in our illustrator represent cropping of **the same original artwork**. Actual camera position, focal length, sensor size and perspective can change the look differently. The preview is NOT a physical lens simulation.
- **Crew roles:** the idea/prepare/shoot/finish panels are simplified common activities. Teams overlap across stages, small crews may combine responsibilities, and film making structures differ. This is neither a list of exactly 24 worldwide crafts nor the formal regional worker federation list.
- **Visual interpretation:** a shot, pause, sound or camera angle may guide attention and suggest emotion; it does not guarantee an emotion or equal reaction among viewers.
- **Action ideas:** learner text is a proposed filming plan, not action actually animated by the current artwork.

## Privacy and safety

Student text lives in local browser storage under new v0.7 keys and is escaped before insertion in HTML. It is not synced or uploaded; switching devices, clearing storage or changing file origins can lose it. The text-export control creates a browser download on the user's device. Existing lesson progress is preserved where the origin is unchanged. All new illustrative visuals are original code-generated SVG elements, not copyrighted film stills.

## Outstanding review before public release

1. Independent film-school educator/content expert reviews 13 lessons, terminology, examples and quiz keys.
2. Telugu phrasing reviewed by fluent speakers; current Telugu sections are short helpers, not a full translation.
3. Real mobile/device visual check for line wrapping, button sizes, visual alignment, file exports and accessibility.
4. Usability test with beginners: learners should distinguish a storyboard from footage and a shot from a take, and can export a comprehensible scene plan.
5. Browser storage, audio, and PWA offline functionality tested on actual devices, not just mocked logic.
