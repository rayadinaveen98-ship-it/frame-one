# Frame One — v0.7 · Learn by Making

**Stage:** Interactive browser-based prototype. Not deployed; not an Android APK or iOS app. No account, cloud server, remote analytics, third-party film clips, or paid services.

## Open and test

Open **`frame-one-v07-open-in-browser.html`** in a browser that supports local HTML. The ZIP contains the full source: serve `index.html` over HTTP(S) for installable-PWA testing. Browser local storage may vary across `file://` locations or when changing domains: downloading another version does **not** guarantee that saved progress or notes will transfer automatically.

## What is available

- 13 complete beginner lessons and quizzes (unchanged content). Each retains its beginner creative-choice exercise.
- Five selected lessons now include a three-frame illustrated learning activity. Each is labelled as a storyboard, **not** moving footage.
- Optional local lesson reflection notes; manually saved in the current browser, separate from completion progress.
- Five learning spaces in Creative Lab: **Frame**, **Sound**, **Cut**, **Light** (retained from v0.6), and **Make** (new).
- **Make**: choose a simple story question around a person waiting at a fictional bus stop; choose wide/medium/close-up framing for each of three beats; write what would happen in each planned shot; save locally or export a plain-text shot list. The drawing illustrates framing and does not dynamically act out the written screenplay.
- **Craft map**: select idea, pre-production, shooting and finishing to see example collaborating roles; tap a role to read about it. This is not a universal mandatory crew breakdown.
- Six chapters, 13 available lessons and 20 planned (not yet written) topics; 20-term glossary with Telugu term labels; 13 short Telugu helper summaries (not complete translations); nine intro film roles.
- Original local completion key `frameone-progress-v01` preserved; new private local keys `frameone-scene-v07` and `frameone-practice-v07` for authored content.

## Quick path to try

1. Open **Learn** → *Frames, shots and scenes* → select the three storyboard images.
2. In **Creative Lab** select **Make** → pick Mystery/Reunion/Decision → change the three shots and add action descriptions.
3. Press **Save scene**; then **Export shot list** to download a `.txt` file.
4. Explore **Meet Film Roles** → switch between the four production stages.

## Tests

```sh
node test-runtime.cjs
node test-audio-and-controls.cjs
node test-v07.cjs
```

Existing regressions plus local draft persistence, escaped user text, exported plans, new navigation, note saving, and crew-stage changes passed mocked browser tests. Three SVG story-framing samples were rendered and visually inspected. **Live browser/device screenshot QA could not run in this environment** because local Chromium execution was blocked; real-browser/mobile touch, keyboard, screen-reader, file-download and audio-output verification remain necessary. Independent filmmaking educator review remains outstanding.

See `ROADMAP.md` and `CONTENT_ACCURACY_V07.md`.
