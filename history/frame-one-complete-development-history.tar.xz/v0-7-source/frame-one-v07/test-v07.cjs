const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
let code=html.match(/<script>([\s\S]*?)<\/script>/)[1];
code=code.replace(/\}\)\(\);\s*$/,`globalThis.__f07={state,storyPlanText,saveStory};})();`);
const memory={};let exported=false;
function boot(){
 const events={},el={content:{innerHTML:''},progressCircle:{style:{setProperty(){}}},progressLabel:{textContent:''},storyStatus:{textContent:''},storyNote:{value:''},lessonPractice:{value:''}};
 const doc={getElementById:k=>el[k]||null,querySelectorAll:()=>[],querySelector:()=>({scrollIntoView(){}}),addEventListener:(k,fn)=>events[k]=fn,createElement:()=>({click(){exported=true},remove(){}}),body:{appendChild(){}}};
 const ctx={document:doc,Blob,URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}},localStorage:{getItem:k=>memory[k]??null,setItem:(k,v)=>memory[k]=v},window:{addEventListener(){},scrollTo(){}},navigator:{},history:{replaceState(){},pushState(){}},location:{hash:'',protocol:'file:'},confirm:()=>true,console,Set,clearTimeout,setTimeout};
 vm.runInNewContext(code,ctx);
 function click(dataset){events.click({target:{closest(){return {dataset,id:''}}}});return el.content.innerHTML}
 return {ctx,el,events,click};
}
let t=boot();
assert(t.el.content.innerHTML.includes('New: make your first three-shot scene'));
assert(t.click({page:'lab'}).includes('Interactive crop'));
assert(t.click({lab:'story'}).includes('Plan a tiny scene.'));
assert(t.el.content.innerHTML.includes('STORYBOARD · SHOT 01'));
assert(t.el.content.innerHTML.includes('Export shot list'));
assert(t.click({storyQuestion:'reunion'}).includes('Who might the person meet?'));
assert(t.click({storyShot:'close'}).includes('CLOSE'));
assert(t.click({storyStep:'1'}).includes('What new information do we learn?'));
t.el.storyNote.value='<img src=x onerror=alert(1)> My small story';
t.events.input({target:{id:'storyNote',value:t.el.storyNote.value}});
assert(t.ctx.__f07.state.story.notes[1].includes('<img'));
assert(t.click({storyStep:'1'}).includes('&lt;img src=x onerror=alert(1)&gt;'));
assert(!t.el.content.innerHTML.includes('<img src=x onerror=alert(1)>'),'user notes escaped');
assert(t.ctx.__f07.storyPlanText().includes('SHOT 2 · Middle'));
assert(t.ctx.__f07.storyPlanText().includes('My small story'));
t.click({storyExport:''}); assert(exported,'download action triggered');
t=boot();t.click({page:'lab'});t.click({lab:'story'});
assert(t.el.content.innerHTML.includes('Who might the person meet?'),'persisted question');
assert(t.el.content.innerHTML.includes('CLOSE'),'persisted framing');
assert(t.click({page:'crafts'}).includes('One film. Many helping hands.'));
assert(t.click({crewPhase:'finish'}).includes('Finish the film'));
assert(t.el.content.innerHTML.includes('Film Music'));
assert(t.click({craft:'music'}).includes('Composers can write original music'));
assert(t.click({lesson:'units'}).includes('A storyboard is not a recorded shot'));
assert(t.click({miniStep:'2'}).includes('Several planned shots could be filmed'));
t.el.lessonPractice.value='A person finds a message';
t.click({savePractice:''});assert(memory['frameone-practice-v07'].includes('finds a message'));
t=boot();assert(t.click({lesson:'units'}).includes('A person finds a message'),'lesson notes saved');
for(const id of ['story','making','script']){assert(t.click({lesson:id}).includes('Plan your own three-shot scene'))}
assert(t.click({openStory:'1'}).includes('Plan a tiny scene.'));
assert(html.includes('prefers-reduced-motion'),'reduced motion');
assert(html.includes('max-width:760px'),'mobile styles');
console.log('PASS v0.7: scenario and framing controls; storyboard drafts survive reload; escaped user text; local shot-plan export; crew-map stages and craft links; in-lesson mini scenes; local practice notes; links and prior content.');
