# Frame One · v0.4 content and accuracy notes

October 26, 2026 · Developer/editorial QA. **Not a certification of 100% accuracy and not an independent filmmaker review.**

## Verified educational distinctions

| What is being taught | Beginner-safe wording | Important limit |
|---|---|---|
| Wide vs medium vs close-up | These names describe how much of the subject and surrounding scene appears in the picture. | No single shot size guarantees a mood. The original Frame Lab crops one drawing; it does not model focal length, depth of field, perspective or camera movement. |
| Front light | Light coming toward the front of a subject can help make facial detail visible. | Intensity, diffusion, placement and exposure also affect the result. |
| Side light | A subject can have a brighter side and a darker side, making lighting contrast noticeable. | Shadows are affected by other lights, light size, surfaces and diffusion. |
| Back light | A light behind the subject can help outline edges. | Silhouettes or dark facial detail are not guaranteed; front/fill light can preserve detail. |
| A shot vs a scene | A scene may contain one uninterrupted shot or several; cuts change the onscreen view. | An illustrated sequence is a storyboard, not automatically a finished film sequence. |
| Single clock image | It makes viewers notice a specific time or wonder about waiting. | A still clock does not show a duration passing unless other visual or contextual information does that. |
| '24 crafts' | A Telugu industry-specific film-worker categorization. | Not one universal list of worldwide professions. |
| Music vs all sound | No background music does not mean no ambience or effects. | The Sound Lab's silent option plays no sound; a film without music need not be silent. |

## Sources checked for introductory terminology

- Adobe, [Different types of shots and camera angles in film](https://www.adobe.com/in/creativecloud/video/production/cinematography/camera-shots-and-angles.html) — close/medium/wide categories, artistic purpose (avoid interpreting tendencies as laws).
- Australia's Screen Online / NFSA, [Glossary](https://aso.gov.au/about/glossary/) — frames, long shots, medium shots, high/low angles, mise-en-scène.
- KQED Education, [Media Production Glossary](https://ww2.kqed.org/education/wp-content/uploads/sites/38/2014/03/12-Media-Production-Glossary.pdf) — definitions of directional lighting and key/fill/back lights.
- ARRI Academy, [Lighting User Training](https://www.arri.com/en/learn/arri-academy/arri-certified-courses/certified-user-training-for-lighting) — light properties and technical/practical complexity.

These sources establish standard foundational vocabulary. Their existence does **not** validate each original educational drawing or the app's pedagogy.

## v0.4 corrections and safeguards

1. Cut Lab changed "We notice the time passing" to "We notice the clock" because a single still cannot prove time has elapsed.
2. Light Lab explicitly describes all visuals as original simplified illustrations, not accurate physical lighting models.
3. Outcomes are expressed as "can", "may", and "might" where cinematic meaning depends on context.
4. Practice uses a stationary object and safe household lamp rather than instructing beginners to use hot studio lights.
5. Telugu summaries remain clearly labeled as short explanations, not full translation.
6. Lesson quiz answers and language/helper/progress flows were rerun through automated logic tests.

## Still pending before public release

- Independent review by at least one filmmaking educator or knowledgeable working filmmaker.
- On-device inspection of visual diagrams on small phones, accessibility and focus testing with a real browser.
- Usability session with beginner viewers to uncover ambiguous words and misleading interpretations.
- Full translation review by a Telugu speaker familiar with film terminology, before claiming complete Telugu support.
- More hands-on examples from the user's own original video footage, if available and licensed.
