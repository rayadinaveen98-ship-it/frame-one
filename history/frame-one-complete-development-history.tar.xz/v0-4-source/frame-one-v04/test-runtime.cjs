// Lightweight DOM-contract integration test for offline prototype.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
let store={};
function boot(){
  const events={};
  const el={content:{innerHTML:''},progressCircle:{style:{setProperty(){}}},progressLabel:{textContent:''}};
  const document={getElementById:id=>el[id]||null,querySelectorAll:()=>[],querySelector:()=>({scrollIntoView(){}}),addEventListener:(type,fn)=>events[type]=fn};
  const ctx={document,localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v},window:{addEventListener(){},scrollTo(){}},navigator:{},history:{replaceState(){}},location:{hash:'',protocol:'file:'},confirm:()=>true,console,Set};
  vm.runInNewContext(script,ctx);
  function click(ds={},id=''){
    events.click({target:{closest(){return {dataset:ds,id}}}});
    return el.content.innerHTML;
  }
  return {el,click,events};
}
let {el,click,events}=boot();
assert(el.content.innerHTML.includes('Start your first lesson'));
assert(el.content.innerHTML.includes('New: explore how lighting changes a face'));
assert(click({page:'learn'}).includes('Film words, explained simply'));
assert(el.content.innerHTML.includes('సినిమాటోగ్రఫీ'));
assert(el.content.innerHTML.includes('12 words'));
assert(click({lesson:'why'}).includes('People watch films for many reasons'));
assert(!el.content.innerHTML.includes('Telugu quick explanation'));
assert(click({telugu:''}).includes('Telugu quick explanation'));
assert(el.content.innerHTML.includes('డాక్యుమెంటరీలు'));
assert(click({telugu:''}).includes('తెలుగులో సులభంగా చెప్పు'));
assert(!el.content.innerHTML.includes('Telugu quick explanation'));
const cases=[
  ['why',1],['units',0],['shot',1],['story',1],['crew',2],['sound',0],['camera',1],['making',1]
];
for (const [id,ans] of cases){
  click({lesson:id});
  assert(el.content.innerHTML.includes('A QUICK CHECK-IN'),id);
  assert.equal((el.content.innerHTML.match(/class="quiz-option /g)||[]).length,3,id);
  click({answer:String(ans)});
  assert(el.content.innerHTML.includes('✓ Exactly.'),id);
}
// Progress preserved across a version upgrade (same original storage key).
click({lesson:'why'});click({answer:'1'});click({complete:''});
assert.equal(el.progressLabel.textContent,'1/8 lessons');
({el,click,events}=boot());
assert.equal(el.progressLabel.textContent,'1/8 lessons');
// lesson deep-link now navigates to the correct lab.
click({lesson:'units'});assert(click({openCut:'1'}).includes('Three shots. One scene.'));
assert(el.content.innerHTML.includes('Shot 1 of 3'));
assert(click({cutNext:''}).includes('Shot 2 of 3'));
assert(el.content.innerHTML.includes('Close-up · The clock'));
assert(click({cutOpening:'detail'}).includes('Starting with the clock'));
assert(el.content.innerHTML.includes('Close-up · The clock'));
assert(click({cutStep:'2'}).includes('Shot 3 of 3'));
assert(el.content.innerHTML.includes('Wide shot · The place'));
assert(click({cutPrev:''}).includes('Shot 2 of 3'));
// New illustration and lighting directions have distinct instructional states.
click({lab:'frame'});assert(el.content.innerHTML.includes('STORYBOARD · SHOT SIZE'));
assert(click({frame:'close'}).includes('236 124 168 94.5'));
click({lab:'light'});assert(el.content.innerHTML.includes('Light changes what we see.'));
assert(el.content.innerHTML.includes('Front lighting is one option'));
assert(click({light:'side'}).includes('one side of the face brighter'));
assert(click({light:'back'}).includes('Light from behind can outline'));
assert(el.content.innerHTML.includes('TRY IT WITH A PHONE'));
click({lesson:'camera'});assert(el.content.innerHTML.includes('lesson-pagination'));
assert(el.content.innerHTML.includes('Next lesson'));
assert(click({openLight:'1'}).includes('Light changes what we see.'));
// Existing frame and sound demos remain accessible.
click({lab:'frame'}); assert(click({frame:'close'}).includes('The face takes up more of the picture'));
click({lab:'sound'}); assert(click({sound:'warm'}).includes('These simple notes might'));
click({page:'crafts'});assert(click({craft:'editing'}).includes('The editor chooses recorded shots'));
console.log('PASS v0.4: 8 lessons/quizzes, progress, Telugu helper, glossary, frame/light/sound/cut labs, lesson pagination and deep-links');
