# Frame One — v0.4 beginner prototype

Frame One is a **working-title**, beginner-first filmmaking learning prototype. It is a self-contained static HTML/CSS/JavaScript app and an optional PWA, not yet a native Android APK or iOS app. It is designed to be simple, interactive, factual and accessible without an account.

## Try it

- **Simplest:** Open the separately packaged `frame-one-v04-open-in-browser.html` file (outside this source folder) in Chrome, Edge or another modern desktop browser. This has no online dependencies.
- **Project source:** Open this folder's `index.html`; to enable PWA/service-worker features, serve the folder via HTTPS or localhost (e.g. `python -m http.server 8000`).
- **On a phone:** Hosting the project on HTTPS is the easiest way to try it. Direct HTML opening from phone file apps is inconsistent. No hosting, domain or Android APK is included.

## What is available

- 8 short beginner lessons, with a three-choice factual check for each and locally saved completion status.
- 9 introductory filmmaking jobs/roles, an explanation that the Telugu film industry's "24 crafts" is not a universal worldwide job count.
- Optional Telugu **summary** for each of the 8 lessons (not full bilingual translation).
- 12-word English/Telugu film vocabulary glossary.
- **Frame Lab:** three shot sizes shown through crops of one original vector storyboard. This is a visual reframing comparison, not a lens or physically accurate camera simulation.
- **Sound Lab:** three choices, including no playback and two simple synthesised original tone sketches. They aren't full music tracks or prerecorded audio.
- **Cut Lab:** a storyboard of three drawings in one situation, changing the opening shot and reviewing the order. Not moving video; a single clock still cannot show time passing.
- **NEW Light Lab:** front, side and back-light choices over an original drawing, with changed light/shadow illustration and cautious context-sensitive descriptions. Not a physical ray-tracing or actual studio-lighting simulation.
- **NEW Storyboard visual:** more useful, consistent spatial setting for wide, medium and close-up than the old scaled silhouette.
- **NEW Navigation:** previous/next lesson controls and page-to-page browser history behavior for normal supported browsers.
- Focus/keyboard improvements for rerendered experiment choices; responsive mobile layout adjustments.

## Privacy and offline behavior

No sign-up, cloud account, analytics trackers, external scripts or paid libraries. Progress is held on the device in localStorage under `frameone-progress-v01`, unchanged from v0.1–v0.3. This is browser-local, can disappear when local data is cleared, and is not synced. Tamil/Hindi or other full translations are not in this version.

## Test

`node test-runtime.cjs` validates core application logic with a lightweight DOM shim. This includes all 8 quiz answer keys, local progress compatibility, Telugu helper toggle, all four labs, Cut Lab ordering, lesson pagination and direct lab links. The authoritative JavaScript is embedded in `index.html` and was also checked with `node --check` after extraction during build validation.

**Visual browser QA was blocked in the available execution environment** (`ERR_BLOCKED_BY_ADMINISTRATOR` for file:// and localhost URLs), so no claim of real browser layout verification can be made. Test manually on desktop Chrome and an Android phone before sharing with learners. The interactive module copy and terminology have been reviewed against the sources in `CONTENT_ACCURACY_V04.md`, but this remains a prototype; an educator review is still required.

## Scope limitations

No licensed film clips, poster images, real camera video, microphone/camera access, user uploads, expert feedback, cloud sync, monetization or external API integrations. Not yet a packaged app-store product.

## Next sensible step

Real beginner usability testing, polish layout issues found on phones, and improve the narration/examples rather than expanding to dozens of lessons prematurely. Keep an error/correction log and solicit independent filmmaker feedback.
