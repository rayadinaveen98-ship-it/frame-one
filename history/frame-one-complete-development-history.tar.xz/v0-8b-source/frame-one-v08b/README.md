# Frame One v0.8B — Beginner Curriculum Complete

**Prototype only**, not yet a hosted web app or native Android/iOS application. Working name: Frame One. Local browser storage; no accounts, third-party tracking, or unlicensed film clips.

## Run
Open `index.html` in your browser, or use the self-contained `frame-one-v08b-open-in-browser.html`. A hosted HTTPS origin is needed for reliable PWA installation/offline service-worker features; local `file://` pages are only for testing.

## What's included
- 33 available beginner lessons, grouped in six chapters, with three accessible explanatory sections, interactive choices, exercises and quizzes.
- 7 creative labs: Frame, Sound, Cut, Light, Make, Colour and Continuity.
- 47 film glossary entries with Telugu term labels; 33 optional short Telugu explanations (not full translation).
- 9 foundational film roles, production-stage collaboration exploration.
- Three-shot scene-planning lab, shot-list TXT export, lesson practice notes.
- Local backup JSON export/import and progression preservation with the original IDs and storage keys.

## What remains
See `ROADMAP.md`, `CONTENT_ACCURACY_V08B.md` and `TECHNOLOGY_DECISION_2026.md` for next work, review limits and platform migration plan.

## Automated tests
Run with a recent Node.js release:

```sh
node test-runtime.cjs
node test-audio-and-controls.cjs
node test-v08.cjs
node test-v08b.cjs
```

These are mocked-DOM logic tests. They are not a substitute for visually testing in actual browsers, iOS Safari/WKWebView and Android Chrome/WebView. Headless Chromium screen capture could not complete in this environment.

## Compatibility
Saved lesson IDs and keys remain `frameone-progress-v01`, `frameone-practice-v07` and `frameone-scene-v07`. Different downloaded HTML file origins may not share storage. Use the **Learn > Keep a copy of your learning** backup before changing devices, browser or prototype file.
