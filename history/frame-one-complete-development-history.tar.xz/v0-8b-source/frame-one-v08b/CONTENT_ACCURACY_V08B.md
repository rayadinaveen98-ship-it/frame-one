# Frame One v0.8B — Curriculum Accuracy Notes

**Scope:** Ten new lessons, two original labs and terminology additions. This is an internal educational review, **not** independent filmmaker or Telugu-language certification.

## Newly completed lessons

1. **Show a feeling through action** — Visual communication and dialogue can coexist. “Show, don't tell” is a suggestion, not an absolute ban on speech.
2. **How colour guides attention** — Palette and colour effects are contextual. The app's overlay is **not** technically accurate colour grading or a lens/camera simulator.
3. **Make separate shots feel connected** — Prop placement is one simple part of continuity. Distinguish deliberate discontinuity from an accidental mismatch.
4. **How editing creates rhythm** — Duration influences attention; short shots do not automatically imply excitement and long ones do not always imply calm.
5. **What are the Indian 24 crafts?** — Specific Telugu federation/worker classification, not 24 universal roles or mandatory crew size. **An exact enumerated 24-association list is intentionally not asserted without a primary source**; this is an accessible introductory context lesson.
6. **How departments plan one scene** — Collaborative filmmaking, no rigid global department structure.
7. **From first idea to finished film** — Development, pre-production, production, post-production and distribution can overlap.
8. **Shoot a small scene with a phone** — Consent/safety, usable sound and review of recorded takes; no rule demanding exactly 3 shots.
9. **Edit a short story from your shots** — Editing chooses shots/takes for clarity and purpose; finishing media is not necessarily precisely 60 seconds.
10. **Watch, learn and improve** — Constructive review favours specific observation rather than universal ratings of creativity.

## Two new hands-on demonstrations

- **Colour Lab** compares one original drawing under neutral, warm and cool **coloured overlays**. It explicitly disclaims colour accuracy, grading and universal emotion claims. There is no promise of actual footage.
- **Continuity Lab** holds one illustrated top-down desk view fixed and toggles an unchanged vs moved cup. It explains real angle-dependent left-right differences and notes deliberate discontinuity is possible. It is not a film editing/rendering simulation.

## Sources used for factual checks

- Telugu Film Chamber of Commerce, federation wage and working-condition records: https://www.telugufilmchamber.in/federation-wages
- The Hollywood Reporter India, description of Telugu federation's 24 worker categories (2025): https://www.hollywoodreporterindia.com/features/insight/telugu-film-employees-federation-call-for-strike-demands-higher-wages
- India Cine Hub, film craft and trade associations: https://www.indiacinehub.gov.in/trade-associations
- Learn About Film, continuity and matching actions: https://learnaboutfilm.com/film-language/sequence/
- Oklahoma State University open textbook, continuity editing/screen direction: https://open.library.okstate.edu/introfilmtv/part/editing/
- StudioBinder educational colour explanation: https://www.studiobinder.com/camera-shots/composition/color-in-film/
- BFI Film Academy, hands-on film-training scope: https://www.bfi.org.uk/bfi-film-academy

## Still required before public launch

- Independent educator/filmmaker fact and curriculum review of **all 33** lessons, not just the new ten.
- Native Telugu editor review; existing text is a *short optional helper summary*, not a complete translation.
- Controlled trials with people who have never studied filmmaking; ask them to explain terms in their own words after lessons.
- Accessibility, small-screen and actual iOS/Android browser testing, including visual comprehension of the new coloured overlays and continuity desk.
- Separate source and licensing records for every production content asset. Current laboratory artwork is authored as original illustrative content.
