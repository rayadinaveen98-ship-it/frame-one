# Frame One — Current Roadmap (v0.8B)

## Product vision
A simple, accurate, visually engaging beginner school for cinema: understand, see, experiment, practise and make a first film. **Working name:** Frame One.

## Completed in the browser prototype

- **33 of 33** planned introductory lessons in **six completed chapters**, with three explanatory sections, an interactive choice, an exercise, a checked question/answer and a short optional Telugu helper per lesson.
- **Seven labs:** Frame, Sound, Cut, Light, Make, **Colour**, **Continuity**.
- **47** English/romanized-to-Telugu labelled film vocabulary entries.
- **Nine** starter film roles plus an interactive crew collaboration map.
- Three-shot storyboard builder with local notes and shot-list export.
- Local progress, notes and storyboard saving; learning backup JSON export/restore. Stable legacy data IDs/keys retained.
- Local scripted browser-logic regression tests. New original illustration-based experiments do not depend on film-clip licensing.

## Important: what is NOT complete

- **The wider scope of global/Indian 24 crafts**: one introductory lesson explains context, not a verified exhaustive association-by-association directory.
- Full Telugu translations, native-language editing and narrated lessons.
- Independent film expert review, real user learning outcome testing, WCAG/accessibility/device visual QA.
- Production web architecture, hosted HTTPS installable PWA, Android APK, signed Android release, iOS build or TestFlight app.
- GitHub repository selection and push.

## Next phase: v0.9 — production foundation

1. Preserve v0.8B as a golden reference with regression tests and backup samples.
2. Migrate progressively to **React + TypeScript + Vite + Capacitor** following TECHNOLOGY_DECISION_2026.md.
3. Validate responsive layout, accessible gestures, motion controls, audio, file import/export, browser deep links and persistently saved progress.
4. Build first reliable **hosted web/PWA beta** under one HTTPS origin.
5. Build Android test version from same web app, with real-device testing; iOS after a Mac/Xcode build route is available.
6. Conduct beginner comprehension sessions; revise lessons before adding advanced content.

## Future after validation

- Proper interactive exploration of the Indian film crafts and how departments collaborate on real productions, with sourced distinctions.
- Complete Telugu translations, optional voice-led learning, more original demonstrations and approachable practical projects.
- Optional user-account/cloud sync only if demonstrated to be useful and affordable.

### Guiding principle
Never trade accuracy, beginner clarity, access or privacy for volume, visual gimmicks or faster launch dates.
