# Frame One · Beginner filmmaking learning prototype

This is an original **functional v0.2 web prototype**, built on October 26, 2026. The name **Frame One** is temporary, not a finalized brand.

## Open it

Double-click `index.html` in a modern browser (Chrome, Edge, Safari, Firefox). No installation, account, network or build step is required. On mobile, deploy the folder to an HTTPS static host to open and install it using **Add to Home Screen**. No hosted URL is supplied with this ZIP. `file://` opening varies by mobile browser. To test locally on desktop, you may also run `python -m http.server 8000` in this directory and visit `http://localhost:8000`.

## What's working

- Home and navigation optimized for desktop and small-screen phones
- Eight short original beginner lessons with simplified, revised explanations
- Short check-in quizzes and completion tracking
- Frame Lab with wide / medium / close visual comparison
- Sound Lab with three interpretations and optional original tones synthesized locally in the browser
- Nine introductory explanations of common filmmaking jobs and teams
- Lesson search/filter and progress retained locally in browser storage
- No account, backend, external assets or usage tracking
- Optional installable PWA with a local/offline cache when hosted over HTTPS or localhost

## Important limitations

- This is a **browser prototype**, not an Android APK or iOS application.
- Visuals are original HTML/CSS illustrations, not licensed film clips.
- Labs illustrate how choices **may** influence viewers; there are no universal rules or objectively 'best' shots.
- The optional Sound Lab audio is a simple Web Audio synthesizer demonstration, not a cinematic score.
- Lesson content received a terminology and plain-language editorial pass against reference materials on October 26, 2026. This is not a professional curriculum certification or a substitute for independent educator review. See CONTENT_REVIEW.md.
- In the Telugu industry, '24 crafts' refers to film-worker categories; this is not a worldwide list of exactly 24 filmmaking jobs. The prototype introduces nine common roles/teams, not the union's full list.
- Progress is stored on the device/browser and is lost if browser storage is cleared.

## Proposed next development steps

1. Test lessons and labs with 5–10 complete beginners. Fix confusing or unhelpful explanations.
2. Add stronger original interactive scene footage/animation and optional Telugu-language content.
3. Add structured paths (understanding films / making first short film), onboarding and accessible motion options.
4. Once the learning design is validated, choose mobile delivery (PWA, Android native, or cross-platform).
5. Create a Git repository after the project name and owner repo are confirmed; this build has not been pushed to GitHub.

## Accuracy-first content policy

- Explain a new technical term in plain language the first time it appears.
- Clearly separate verifiable facts (what a frame or take is) from creative interpretations (what a low angle might suggest).
- Never say a shot size, musical choice or camera angle has one guaranteed emotional effect.
- State exactly what a demo does: the Frame Lab changes a CSS illustration; the Sound Lab plays short synthesized notes, not a composed score.
- Cross-check role boundaries against industry descriptions, and keep regional trade frameworks separate from universal filmmaking concepts.
- Recheck accuracy and run the quiz tests when new lessons are added.

