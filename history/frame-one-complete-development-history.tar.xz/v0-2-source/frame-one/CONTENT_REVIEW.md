# Frame One content review — v0.2

Date: 26 October 2026
Scope: all eight introductory lessons, quizzes and feedback, all nine job/role descriptions, Frame Lab and Sound Lab explanatory labels.

## Editorial changes applied

1. **Films are not always fictional stories.** Lesson 1 now also mentions information, documentaries, entertainment and different audience reactions.
2. **Frame, shot, scene, take:** Lesson 2 now explains each term separately. A single continuous recording is a *take*; a *shot* is an uninterrupted view in the finished film; a *scene* is a part of the action and can contain one or more shots. These are beginner-friendly working definitions, not exhaustive descriptions of all experimental-film practices.
3. **Aesthetic choices are context dependent.** Lessons on framing, camera angles and music avoid claiming that a choice always causes a particular emotion or equals a universally “best” shot.
4. **Filmmaking roles are not identical to the Telugu '24 crafts' trade structure.** Nine cards represent a selected introductory set of roles and teams rather than an official list of 24 federated categories. The text now says this explicitly.
5. **Simpler technical language:** Several unnecessary specialist terms were removed or explained, including composition, stakes, screenplay, take and camera placement.
6. **Frame Lab limitations:** The size of an original CSS silhouette changes; this is a framing illustration, *not* a physically accurate simulation of moving a camera, focal length or perspective.
7. **Sound Lab limitations:** The no-music option plays no audio, the warm/tense options generate only simple monophonic computer tones, and the scene is imagined—not recorded footage paired with multiple film scores. The labels now reflect this.
8. **Small filmmaking advice:** Lesson 8 simplifies planning, sound checks, cut/editing and obtaining permission for music.

## Reference material checked

These links ground terminology and role descriptions. Reference pages are not copied into the app.

- Film Education, *Glossary of Film Terminology*: https://www.filmeducation.org/resources/primary/teaching_with_film/film_in_primary_literacy/glossary_of_film_terminology/
- University of West Georgia, *Glossary of Film Terms*: https://www.westga.edu/academics/university-college/writing/glossary_of_film_terms.php
- StudioBinder, *What is a Take?*: https://www.studiobinder.com/blog/what-is-a-take-in-film-definition/
- Film Education, *Sound*: https://filmeducation.org.uk/resources/primary/topics/sound/
- ScreenSkills, *Film and TV drama roles*: https://www.screenskills.com/job-profiles/browse/film-and-tv-drama/
- ScreenSkills, *Director of Photography*: https://www.screenskills.com/job-profiles/browse/film-and-tv-drama/technical/director-of-photography-dop/
- ScreenSkills, *Production Designer*: https://www.screenskills.com/job-profiles/browse/film-and-tv-drama/craft/production-designer-film-and-tv-drama/
- Cinema Express (3 Aug 2025), *Telugu Film Employees' Federation on 24 worker categories*: https://www.cinemaexpress.com/telugu/news/2025/Aug/03/telugu-film-employees-federation-declares-shooting-halt-over-wage-hike-demand

## Not yet verified by this pass

- This was **not** independent film-educator or union verification. Job responsibilities vary by production scale, country and union.
- No participant comprehension study was conducted. Simple wording can still confuse absolute beginners.
- The Labs are schematic examples; they must not be presented as real camera or sound-production demonstrations.
- The illustrated scene, exact shot size and generated tones should be replaced with suitable original visual/audio demonstrations when building a later course version.

## Future editorial gate

Every new lesson should pass: (1) sources reviewed, (2) factual statements separated from subjective interpretation, (3) jargon explained, (4) one small real-world example, (5) quiz accurately checks what was taught, (6) demonstration and its limitations correctly labelled, (7) ideally reviewed by a filmmaker or educator before public release.
