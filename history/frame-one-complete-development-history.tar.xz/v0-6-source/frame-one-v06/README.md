# Frame One — v0.6 beginner filmmaking prototype

**Status:** Functional single-file browser prototype and optional progressive-web-app source. **Not** an Android/iOS build and not yet deployed.

## Try it

Open `frame-one-v06-open-in-browser.html` in a modern desktop or mobile browser. You do not need an account, network connection, login, API key, or copyrighted film assets. On mobile, open it in a browser that permits local HTML files. The source `index.html` is designed to be served over localhost/HTTPS to enable manifest and service worker.

## Included (carried forward without erasing previous progress)

- 13 complete beginner lessons with short creative-choice exercises and three-answer quizzes.
- Six course chapters, with 20 additional **planned** lessons clearly labelled as future work.
- 20-word English/Telugu terminology glossary and short Telugu helpers for each lesson (not a full Telugu localization).
- Nine starter filmmaking roles and a careful explanation of the Indian “24 crafts” usage.
- Same localStorage progress key as earlier releases: `frameone-progress-v01` (saved progress persists on the **same browser and origin**, not automatically across different file paths, browsers, devices or hostnames).

## v0.6 labs

- **Frame Studio:** Same original illustration with cinematic overlays; select wide/medium/tight presets, fine-tune crop between 1× and 3×, toggle composition guides, compare different crops. **This is a 2D crop, not a lens or camera movement simulator.**
- **Sound Studio:** The same illustrated scene remains onscreen. Play synthesized gentle/uneasy note sketches with optional quiet synthesized ambient noise. “No music” intentionally differs from total silence. Requires a user click for browser audio. Stop/play lifecycle and five-second progress feedback.
- **Lighting Studio:** Choose front/side/back lighting plus illustrative brightness and shadow-edge softness sliders. The side-light shadow-edge control is the clearest demonstration. This is an artist-drawn model, not real lighting physics.
- **Cut Studio:** Three original storyboard shots; reorder, choose 1–5 seconds each, play the timed sequence and see a moving clip playhead. This is an editing concept demonstration, not an actual video editor.

All moving effects respect `prefers-reduced-motion`. Original SVG/vector drawings and procedural Web Audio are created inside the app; no remote media are fetched.

## Tests and limitations

Run:

```bash
node --check check-syntax.js
node test-runtime.cjs
node test-audio-and-controls.cjs
```

The 13 quiz answer keys, progress compatibility, cross-lesson navigation, clip edit/playback, new interface controls, and mocked browser audio flows passed. The original visual SVG samples were rendered and inspected offline. End-to-end Chromium browser and responsive screenshot verification remains blocked in this environment; browser-level cross-device visual, audio-output and accessibility testing still must be completed on real devices. Content also needs independent filmmaker/educator review.

See `CONTENT_ACCURACY_V06.md` and `ROADMAP.md`.
