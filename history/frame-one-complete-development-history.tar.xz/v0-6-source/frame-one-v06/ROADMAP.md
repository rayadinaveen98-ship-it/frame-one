# Frame One — roadmap through v0.9

**Current shipped prototype: v0.6.** See README for tested features and caveats.

**v0.6 complete (source tested, device QA pending):** four richer labs with an animated vector film monitor, finer framing/crop, more lighting controls, scene-based sound with optional ambience, and a timeline playhead. All 13 previous lessons and local completion data retained.

**v0.7 planned:** make lessons more experiential through original short sequential animations and reusable on-lesson micro labs; build a simple storyboarding and shot-list exercise.

**v0.8 planned:** expand 13/33 lessons thoughtfully toward the 33-lesson beginner learning outline and get independent editorial reviews; complete Telugu translations and accessibility refinements.

**v0.9 planned:** beginner usability trials; robust browser cross-device QA; establish a versioned repository, release pipeline and Android test package.

---

# Frame One — beginner-first product and curriculum plan

**Working title:** Frame One. **Current prototype:** v0.5. **Audience:** people with zero filmmaking experience, and curious cinema lovers. **Core promise:** understand a small film idea, try a creative decision, and see a plausible effect. The experience is original, accessible, and no account is required.

## Teaching philosophy

- Lead with simple real-life questions, *then* introduce terminology.
- Teach accurate distinctions: frame vs shot vs take vs scene; soundtrack vs music; camera placement vs lens optics; timing vs movement; regional “24 crafts” vs worldwide department structures.
- Where filmmaking choices are subjective, present them as possibilities: *may, can, depends on the context*. Avoid memorising fake universal rules.
- For each chapter: **Wonder → Compare → Choose → Explain → Try → Check**. Each chapter consists of short 3–6 minute lessons; new chapters receive one original interactive example and one optional phone exercise.
- Use original illustrations and/or properly licensed media. Film scenes and soundtracks can't be assumed to be free to redistribute.
- English primary, short Telugu summaries as support. Full Telugu curriculum and other language choices require editorial review.

## Current learning tree: 13 available lessons, 20 planned lessons (33 total)

| Chapter | Available now | Next lessons planned (not yet implemented) | Chapter demonstration |
| --- | --- | --- | --- |
| 1. Discover cinema | Why we watch; Early cinema; Frame/shot/scene | Kinds of films; How cinema grew in India | Frame vs shot visual compare + historical mini-timeline |
| 2. Tell a human story | Story/emotion; Screenplay; Acting | Character and conflict; Scenes and dialogue; Show, don't just explain | Two versions of a tiny situation / decision game |
| 3. Learn visual language | Shot choices; Camera placement; Lighting | Composition and balance; Movement; Lenses and perspective; Colour | Frame and Light Labs + original side-by-side studies |
| 4. Sound and editing | Sound; Editing | Dialogue and ambience; Music/emotion; Continuity; Rhythm and transitions | Playable original audio sketches + editable three-shot timeline |
| 5. People behind a film | Team roles and Indian 24-craft context | 24-craft industry context; Writing/camera/art teams; Production/post-production | Interactive crew map connecting departments (planned) |
| 6. Make your first film | Idea to first film | Shot lists; Shoot one scene; Edit a 60-second story; Review and improve | Guided first-film challenge / basic storyboard editor (planned) |

The planned list is flexible. We should prioritize accurate lessons and high quality illustrations over a target chapter count.

## Versioned product roadmap

### v0.5 — DONE IN THIS DELIVERY
- Build on v0.4, preserve the `frameone-progress-v01` local progress key and previous lesson IDs.
- Expand from 8 to **13 fully readable lessons with quizzes**. Add: history of cinema; screenplay basics; acting and performance; lighting basics; editing fundamentals.
- Add **13 lesson decision exercises** (creative explorations, not subjective right/wrong quizzes).
- Add a grouped chapter map with clear `available` and `planned` visibility; expand glossary from 12 to 20 terms.
- Add a side-by-side framing comparison and an editable Cut Lab timeline with shot order, per-shot duration and timed preview.
- Improve responsive styles, contrast, keyboard focus and reduced-motion support.

### v0.6 — NEXT: practical learning quality
- Replace static storyboard stages with expressive original moving scenes / animations, while maintaining clear film terms.
- Synchronize the Sound Lab to a short original visual sequence, with captions and an explicit mute/volume control.
- Add a genuine beginner-friendly *light direction, softness, and shadow* visual simulator, checked for technical accuracy (current lab remains a simplified drawn comparison).
- Add micro-activities directly tied to each section rather than one decision exercise per lesson.
- Add guided "Try this on your phone" exercises, with privacy-safe local-only notes.

### v0.7 — guided, practical creative challenges
- Add an illustrated shot-list builder and a simple 45–60 second storyboard scene project.
- Provide a completion artifact/export without accounts or cloud usage.
- Add an interactive craft-connection map and distinguish an industry-specific 24-craft list from general film occupations.
- Implement onboarding: 3-card intro, Choose a learning path, Skip; avoid mandatory signup and gamified pressure.

### v0.8 — full introductory learning path
- Develop the 20 planned lessons, in small batches. Review each by a filmmaker/educator; validate quizzes and translations.
- Optional Telugu full text with editorial review and bilingual glossary.
- Search, bookmarks, accessibility pass, network-independent app test, proper mobile safe areas.

### v0.9 — release readiness
- Real usability tests with 10–20 complete beginners; verify comprehension and actual interaction (not only quiz completion).
- Android installable testing build and iOS browser/PWA evaluation; decide native wrappers only after performance, storage and accessibility checks.
- QA across common phone sizes, slow hardware, portrait orientation, no-network usage, audio policy, keyboard/screen reader interaction.
- Copyright/licensing, privacy and content corrections checklist. No claim of monetization or PMF.

## Definition of done for each lesson
1. Tested factual accuracy with at least one credible reference for new technical/historical claims.
2. Written in simple English with short sentences, one plain example and a clear distinguishing note for related terms.
3. Contains at least one meaningful interactive decision or comparison; it must explain what changed.
4. Every answer key checked, including incorrect feedback; subjective art questions must not have a fake universal right answer.
5. Works on narrow mobile screens, with adequate touch targets, focus visibility, readable contrast, and reduced motion support.
6. Explicitly marks simulations and original artwork, without implying physical realism that the prototype cannot deliver.
7. Independent filmmaking educator review and hands-on visual testing before a public educational release.

## Metrics worth measuring in user trials (not implemented as trackers)
- Can a complete beginner correctly explain 'shot vs scene' and 'no music vs no sound' without prompting?
- Can learners make and explain a creative choice after the exercise?
- Do novices successfully discover, use, and complete one lab in under five minutes?
- Which explanations are confusing or misleading? Log them and fix before increasing chapter count.

## Engineering status
- Offline-capable HTML/CSS/JS prototype, optional PWA assets, no backend/sign-in/analytics.
- Old lesson completion stored locally and kept across versions with the existing `frameone-progress-v01` key. New lessons naturally reduce the completion percentage; previously finished lessons remain finished.
- JavaScript syntax and lightweight DOM-behavior tests available; no full browser visual validation in this environment. No native APK and no source repository designated yet.
