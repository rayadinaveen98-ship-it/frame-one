# Frame One v0.6 — accuracy and teaching-quality notes

## Non-negotiable editorial guidelines
1. Explain a technical term in everyday English before adding technical detail.
2. Distinguish observation from interpretation. Framing, light and music **may** guide attention or suggest a feeling; none guarantees the same emotional result for every viewer.
3. Distinguish an illustration or sound sketch from video footage, lighting physics, a camera lens, musical scoring or professional editing software.
4. Avoid declaring one shot, edit, light or film technique universally “best.” Clarify intended storytelling effect.
5. The Telugu-industry “24 crafts” is an industry-specific collective classification, not an identical worldwide enumeration of film professions.
6. Avoid presenting mini Telugu helpers as full translations; keep full Telugu localization on the roadmap.

## v0.6 new interface semantics

**Frame:** The fine control adjusts a static, drawn image's *crop*. It can demonstrate shot size and visibility but not changes in perspective, field of view resulting from physically changing camera/lens, focus falloff, or actor performance. Guides are composition aids, not mandatory rules.

**Sound:** 'No music' can still have ambience and dialogue in a real film; the prototype's optional background sound is synthetic noise, not a bus-stop field recording. The tonal sketches are not emotionally deterministic, full scores, or authentic samples. User must initiate sound. Moderate playback level by default.

**Lighting:** Front/side/back are simplified directional illustrations. Real light appearance depends on position, size of source, distance, modifiers, bounce, camera exposure, scene and materials. Here brightness changes an illustrated dark overlay; side-light softness modifies a shaded region. Slider percentages are demo-only, not measurable physical units, and should not be called lux/EV or actual lighting ratios.

**Editing:** Duration is a timed still-board preview. The shot-order activity shows when certain visual information becomes available, rather than proving an emotion. A still clock image may draw attention to a time value but does **not** itself depict the passage of time.

**Animation:** Subtle subject animation and film-haze are presentation effects added to original illustrations; they should not be confused with actual recorded action or movement studies.

## Outstanding quality gates
- Formal educator review of the full 13 lessons and 20-term glossary.
- Real browser and mobile visual + touchscreen checks; headless Chromium did not complete in the container.
- Browser audio perception, volume, error/fallback and reduced-motion checks on real devices.
- Telugu phrasing reviewed by proficient speakers before release.
- Beginner usability research: participants must understand what they changed, why, and what the model leaves out.
