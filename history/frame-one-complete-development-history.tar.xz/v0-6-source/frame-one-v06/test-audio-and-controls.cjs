const fs=require('fs'),vm=require('vm'),assert=require('assert');
const js=fs.readFileSync(__dirname+'/index.html','utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
const events={},elements={content:{innerHTML:''},progressCircle:{style:{setProperty(){}}},progressLabel:{textContent:''}};
const osc=()=>({type:'',frequency:{setValueAtTime(){}},connect(){},start(){},stop(){}});
const gain=()=>({gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){}});
let contexts=0,stops=0;
class MockAudioCtx {
 constructor(){contexts++;this.currentTime=0;this.sampleRate=12000;this.destination={}}
 createGain(){return gain()}
 createOscillator(){const o=osc(),old=o.stop;o.stop=()=>{stops++;old()};return o}
 createBuffer(ch,len){return {getChannelData(){return new Float32Array(len)}}}
 createBufferSource(){return {connect(){},start(){},stop(){stops++},set buffer(x){},loop:false}}
 createBiquadFilter(){return {connect(){},frequency:{value:0},type:''}}
 resume(){return Promise.resolve()}
 close(){return Promise.resolve()}
}
const timers=new Map();let next=1;
const ctx={document:{getElementById:id=>elements[id]||null,querySelectorAll:()=>[],querySelector:()=>null,addEventListener:(name,fn)=>events[name]=fn},window:{AudioContext:MockAudioCtx,addEventListener(){},scrollTo(){}},localStorage:{getItem:()=>null,setItem(){}},navigator:{},history:{replaceState(){},pushState(){}},location:{hash:'',protocol:'file:'},confirm:()=>true,Set,console,setTimeout:(fn,ms)=>{let id=next++;timers.set(id,{fn,ms});return id},clearTimeout:id=>timers.delete(id)};
vm.runInNewContext(js,ctx);
const click=ds=>events.click({target:{closest(){return {dataset:ds,id:''}}}});
click({page:'lab'});click({lab:'sound'});click({sound:'warm'});click({audio:'play'});
assert.equal(contexts,1,'creates audio on direct user click');assert(elements.content.innerHTML.includes('Audio playing'));
click({sound:'silence'});assert(!elements.content.innerHTML.includes('Audio playing'),'stop on sound change');
click({audio:'play'});assert.equal(contexts,2,'ambience plays independently of music');click({audio:'stop'});assert(!elements.content.innerHTML.includes('Audio playing'));
click({page:'learn'});assert(elements.content.innerHTML.includes('13 lessons'),'lessons preserved');
click({page:'lab'});click({lab:'frame'});
events.input({target:{id:'frameZoom',value:'2.4'}});
click({compare:''});assert(elements.content.innerHTML.includes('2.4×'), 'continuous custom crop state preserved');
console.log('PASS: user-triggered audio play/stop, ambience with no music, no leaked timers, interactive crop input state, route changes');
