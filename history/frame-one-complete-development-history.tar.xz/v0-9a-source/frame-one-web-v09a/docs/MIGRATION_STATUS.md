# Frame One v0.9A — React lesson migration status

Date: 27 October 2026. A source-code migration milestone, **not** a native or hosted release.

## Implemented and tested in source

- Preserved all **33 existing lessons / six chapters**, **seven creative labs**, **47 glossary terms**, **nine starter film roles**, and the original v0.8B educational content.
- **Migrated the lesson reader to React + TypeScript**: reading sections, 33 interactive creative-choice questions, 33 three-option quizzes, optional short Telugu helpers, practice notes, lesson pagination, and completion flow. 10 original three-beat illustrated storyboard studies are included via data extraction and the existing artwork adapter.
- React now conditionally renders the lesson view and controls its internal interaction state. The legacy runtime owns the home page, chapter explorer, seven labs, production-role map, and export/import backup UI. No React-owned element is rewritten by `innerHTML`.
- Introduced `src/legacy/bridge.ts` as a typed boundary: navigate, open lab, complete lesson, save practice, set Telugu and access fixed original illustration variants.
- Preserved exactly the keys `frameone-progress-v01`, `frameone-practice-v07`, `frameone-scene-v07`, and `frameone-telugu-helper-v03`.
- Fixed a note-saving bug: corrupted JSON in the React notes helper now recovers to an empty object instead of preventing a new note save. For normal data, note changes are synchronized into the legacy backup engine to avoid dropping them from exported backups.
- Updated the manifest paths for deployment under a subpath and bumped the service-worker cache namespace.
- Automated tests: content/key consistency; route event/bridge and completion; existing seven-lab runtime routes; 33 choice mappings and 10 storyboard sets; TSX/TS parsing/transpilation; storage recovery. `npm test` can run without installing third-party dependencies because the test runner uses system TypeScript.
- The dependency-free v0.9 static preview in `preview/` is still bundled as a **functional fallback**, but is intentionally the PRE-MIGRATION lesson experience (it does not have the React lesson reader).

## Important verification limits

- **`npm run build` has not succeeded**. The registry is inaccessible (`EAI_AGAIN`) and React/Vite/Capacitor dependencies aren't installed in the current container. AST/transpilation tests are NOT proof of an installed dependency build or complete TypeScript type checking.
- The migrated React lesson reader has **not** been tested in a running React browser app or on Android/iOS. It may still have integration or visual issues.
- Native projects (`android/`, `ios/`), APK, AAB, IPA, TestFlight, hosted HTTPS URL and GitHub commit have **not** been created. Bundle identifier `com.frameone.learncinema` is **provisional**.
- Visual device QA, offline test, filmmaker fact review and full Telugu editorial review remain pending.

## Build with an available npm network/toolchain

```bash
npm install
npm test
npm run build
npm run dev
```

Then navigate among lessons, quiz and mark complete, save notes and export backup; verify all seven labs, audio, browser back, offline caching, touch, accessibility and mobile safe areas. After a clean web build and package ID decision:

```bash
npx cap add android
npx cap sync android
# Android Studio + Android SDK needed to generate APK
```

On macOS with Xcode for iOS:

```bash
npx cap add ios
npx cap sync ios
```

**Migration note:** If opening the app from a different `file://` or HTTPS origin, prior browser storage will not automatically appear. Export a JSON backup in the old app and restore in the new app before assuming progress migrated.

## Next engineering slice

1. Install and production-build React dependencies in a networked environment; fix any bundler/type errors.
2. Run actual browser/device QA of the React lessons and all seven old labs.
3. Migrate the chapter explorer and glossary to typed React components, then each lab behind the bridge one at a time.
4. Harden offline assets, import/export and native file sharing; verify Android then iOS with actual tooling.
