# Frame One v0.9A — Beginner Film School

Frame One is a beginner-friendly, privacy-first, interactive filmmaking learning app in progress. The course contains 33 short introductory lessons in six chapters, seven creative labs, 47 film terms, nine starter film roles, and optional short Telugu learning notes.

## Current engineering state

**New in v0.9A:** The lesson experience (reading, creative choices, quizzes, 10 illustrated studies, notes and completion) is React + TypeScript. Other screens and labs still use the preserved v0.8B runtime behind a typed compatibility bridge. This is a **source-code handoff**, not a verified hosted or native app.

### Project layout

- `src/components/LessonView.tsx` — React lesson reader and teaching interactions.
- `src/data/curriculum.v08b.json` — curriculum, chapter order, Telugu helpers, glossary and roles.
- `src/data/storyboards.json` — 10 original illustrated storyboard lesson outlines.
- `src/state/learning.ts` — safe local progress, notes and language keys.
- `src/legacy/bridge.ts` — typed navigation and completion integration.
- `src/legacy/runtime.js`, `legacy.css` — original seven labs, navigation, role map and backup UI (temporary bridge).
- `preview/` — unchanged working standalone static-web fallback from v0.9 (not the migrated React reader).
- `docs/MIGRATION_STATUS.md` — detailed engineering status and limitations.

### Install and run (requires access to npm packages)

```bash
npm install
npm test
npm run build
npm run dev
```

An offline test command with system Node and global TypeScript works without npm installation:

```bash
node tests/verify-migration.cjs
node tests/verify-react-lessons.cjs
```

**Important:** This sandbox cannot currently fetch packages from npm. As a result, `npm run build` and running the migrated React UI haven't been verified. To run the previous working experience with no dependencies, serve `preview/` with `python -m http.server`.

To build Android/iOS later, install Capacitor dependencies and the required native SDKs. The current bundle ID is a placeholder.

No backend, tracking account, uploaded practice notes or paid subscription is required. Local work needs a manual backup to move across file or website origins.
