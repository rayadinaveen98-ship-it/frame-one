# Frame One — v0.9 Cross-Platform Migration (Phase 1)

Frame One is a beginner filmmaking app with 33 drafted lessons in six chapters, seven illustrated interactive creative labs, nine starter roles, a 47-term glossary, optional short Telugu helpers, private notes and a three-shot storyboard.

This repo contains two modes:

- `preview/`: a **working no-build static web app** preserving v0.8B functionality. Deploy to any static HTTPS host or run a local web server.
- `src/` and Vite/Capacitor configs: the first **React/TypeScript migration layer**, retaining the existing educational runtime as a compatibility module until each lab is ported.

The current legacy runtime and React shell are not yet independently production-built in this environment due blocked npm registry. Run `npm install && npm test && npm run build` in a networked environment. No native build has been produced.

Commands, migration status, risks and mobile steps: [docs/MIGRATION_STATUS.md](docs/MIGRATION_STATUS.md).

## Responsible teaching and privacy

Lessons are simple beginner-oriented drafts, not yet independently certified; visual experiments are illustrations, not camera/lens/colour-grading simulators. Avoid universal claims about emotional interpretation. Notes/progress stay in local browser storage. No server or accounts. Export a backup before changing domains/browsers or cleaning site data.
