# Frame One v0.9 — Web & mobile migration status

## Implemented in this handoff

- React 19 + TypeScript + Vite project configuration, version-controlled source layout and new React application shell.
- **No rewrite of curriculum or seven labs:** v0.8B educational engine and CSS extracted into dedicated modules as a compatibility bridge. Original lesson identifiers and local storage keys are unchanged.
- Independent typed curriculum export JSON for future stepwise React lesson components: 33 lessons, six chapters, 47 glossary items, nine roles.
- Capacitor 8 configuration for eventual Android/iOS generation, with provisional package ID `com.frameone.learncinema`.
- Revised service worker and web manifest. Online-first same-origin cache supports offline revisits after assets are requested, but device-level offline tests are pending.
- A dependency-free **static web beta** in `preview/`, actually runnable on any static server today. It retains the original familiar interface. No authentication or backend.
- Node regression tests verify content count, quiz answer index bounds, all seven labs, saved progress contract, and static preview structure.

## NOT complete; do not claim otherwise

- The lesson/lab engine is **not yet rewritten as idiomatic React components**. React owns the shared shell and original runtime owns the dynamic lesson content region. This avoids feature regression during the first migration.
- Cannot install npm packages in the current sandbox (`registry.npmjs.org` DNS `EAI_AGAIN`). Thus the Vite production build/React browser runtime and `cap add` commands have NOT been executed or verified.
- No Android/ or ios/ generated native source folder, APK/AAB/IPA, app-store release or hosted HTTPS URL.
- Full browser visual QA, device accessibility, audio behavior and offline testing not performed here. Lesson and Telugu expert review pending.
- Changing from a downloaded `file://` page to HTTPS changes storage origin; instruct users to export a backup in the old app and import it in the new hosted app. The keys are compatible only on the same origin.

## Build and run with internet access

```bash
npm install
npm test
npm run dev
npm run build
npm run preview
```

To run the usable no-dependency preview now:

```bash
cd preview
python3 -m http.server 4173
# visit http://localhost:4173/
```

To prepare Android in a developer machine with Android Studio/JDK/SDK:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

For iOS on a Mac with Xcode:

```bash
npm install
npm run build
npx cap add ios
npx cap sync ios
npx cap open ios
```

**Before native build:** decide permanent app ID, remove any placeholder identifiers, verify WebView audio/storage/backup on real devices, accessibility and copyright, and confirm content review.

## Next engineering phases

1. Run npm/Vite + `cap add` in a networked build environment; fix any toolchain issues.
2. Convert curriculum view and quizzes to typed React components incrementally, maintaining exact output parity.
3. Convert seven labs individually to React state and components with per-lab regression tests.
4. Replace large browser-localStorage collections with versioned IndexedDB, with tested import/export and backup migration.
5. Real Android tests including back gesture, Web Audio, files, safe areas, offline; iOS WKWebView tests and TestFlight.
6. Full educational/factual review and Telugu editorial pass; usability trial with beginner filmmakers.
