import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import './legacy/legacy.css';

// v0.9 migration bridge: React owns the persistent application shell.
// The v0.8B learning runtime owns only the lesson/lab content region during
// this first migration. This makes zero curriculum rewrites necessary.
type Destination = 'home' | 'learn' | 'lab' | 'crafts';
const nav: { id: Destination; title: string; glyph: string }[] = [
  { id: 'home', title: 'Home', glyph: '⌂' },
  { id: 'learn', title: 'Learn Cinema', glyph: '▤' },
  { id: 'lab', title: 'Creative Lab', glyph: '◎' },
  { id: 'crafts', title: 'Meet Film Roles', glyph: '♧' },
];

function Navigation({ mobile = false }: { mobile?: boolean }) {
  return mobile ? (
    <nav className="mobile-nav" aria-label="Mobile navigation">
      {nav.map(item => (
        <button type="button" key={item.id} data-page={item.id}>
          <span aria-hidden="true">{item.glyph}</span><span>{item.id === 'crafts' ? 'Roles' : item.id === 'learn' ? 'Learn' : item.id === 'lab' ? 'Lab' : 'Home'}</span>
        </button>
      ))}
    </nav>
  ) : (
    <div className="nav-menu">
      <div className="nav-label">Explore</div>
      {nav.map(item => (
        <button className="nav-btn" type="button" key={item.id} data-page={item.id}>
          <span aria-hidden="true" className="nav-symbol">{item.glyph}</span>{item.title}
        </button>
      ))}
    </div>
  );
}

function ProgressTopbar() {
  return <header className="topbar">
    <div className="welcome">A little film school, in your pocket.</div>
    <div className="top-right">
      <div className="progress-pill">
        <span className="progress-circle" id="progressCircle" style={{'--angle':'0%'} as CSSProperties} />
        <span id="progressLabel">0/33 lessons</span>
      </div>
      <div className="avatar" aria-hidden="true">F1</div>
    </div>
  </header>;
}

export default function App() {
  const [bootError, setBootError] = useState<string | null>(null);
  useEffect(() => {
    // Run after React mounts the legacy DOM targets, once per app lifetime.
    import('./legacy/runtime.js').catch(() => setBootError('Learning content could not load. Please refresh the page.'));
  }, []);

  return <div className="app">
    <aside className="sidebar" aria-label="Main navigation">
      <a className="logo" href="#home" id="brand" aria-label="Frame One home">
        <span className="logo-mark" aria-hidden="true">▧</span>
        <span className="logo-type">FRAME ONE<span>THE ART OF FILM</span></span>
      </a>
      <Navigation />
      <div className="sidebar-bottom">
        <div className="side-note"><strong>Learn at your pace.</strong>No account. No pressure. Just cinema.</div>
        <button className="ghost-reset" id="resetProgress" type="button">Reset learning progress</button>
      </div>
    </aside>
    <main className="main" id="main-content">
      <ProgressTopbar />
      {bootError ? <p role="alert">{bootError}</p> : null}
      <div id="content" aria-live="off" />
      <footer className="footer"><span>FRAME ONE · Web migration v0.9</span><span>Made for curious minds <span className="heart">♥</span></span></footer>
    </main>
    <Navigation mobile />
  </div>;
}
