# Frame One — v0.8 | Beginner Curriculum, Part 1

**Stage:** Local browser-learning prototype, **not** an Android APK or public release. No account, cloud services, analytics or unlicensed film clips. Working name: Frame One.

## Try it

- Open `frame-one-v08-open-in-browser.html` in Chrome, Edge or another compatible browser.
- Select **Learn** to explore the six-chapter path; all 23 available lessons contain a creative decision, three simple reading sections, a practice idea and a quiz.
- Check the five Creative Labs (Frame, Sound, Cut, Light, Make) and interactive craft map, retained from v0.7.
- Try **Learn → How did cinema grow in India?**, **Arrange the frame**, **What do lenses change?**, or **Plan shots before you shoot**.
- Under **Learn → Keep a copy of your learning**, export a `.json` backup before switching files/browsers. Restore it later via the same section. Keep the backup private: it includes reflection notes and your scene draft.

## Implemented this release

- Added **ten** researched introductory lessons: Genres; Indian Cinema History; Character, Want & Obstacles; Dialogue; Composition; Camera Movement; Lenses & Perspective; Dialogue/Ambience; Music; Shot Lists.
- All ten include two possible creative choices and checked factual-answer quizzes. Five add an illustrated three-step storyboard exercise. The remaining new lessons link to an appropriate existing lab when technically honest.
- **23 total lessons** (13 preserved from v0.7), **six chapters**, **10 topics visibly planned** but not implemented, **35 plain-language film terms** with Telugu labels.
- Short optional Telugu summaries for all 23 lessons. These are not professionally reviewed full translations.
- Fixes the lesson-filter grouping for Sound; the old sound/editing lessons are reclassified in this UI category without changing their contents or storage IDs.
- Adds explicit local JSON backup/export and checked restore for completion records, lesson notes and the three-shot storyboard. Invalid extra IDs are ignored; text is length-bounded and escaped on display.
- Refreshes the PWA service-worker cache name to v0.8; note that an installable PWA must be served over HTTP(S) or localhost, not opened using file://.

## Existing work is preserved

- `frameone-progress-v01` lesson completion storage key remains unchanged.
- `frameone-practice-v07` reflection notes remain unchanged.
- `frameone-scene-v07` storyboard remains unchanged.
- The four older labs, Make Lab, shot-list export and visual craft collaboration map remain.

**Important portability:** Browser storage on local HTML files may depend on their file origin. Opening a new downloaded HTML file does **not** guarantee previous local progress appears automatically. Use the new backup/export feature to transfer data, while still preserving the original storage keys for users who open versions under the same origin.

## Tests and remaining QA

```sh
node test-runtime.cjs
node test-audio-and-controls.cjs
node test-v08.cjs
```

These are automated logic tests in a mocked browser environment; they are not a substitute for genuine Android/iPhone/browser-device testing. A local headless Chromium run could not complete in this environment. Audio, keyboard navigation, device touch, file chooser, offline PWA installation and full screen-reader QA require real browsers/devices. An independent filmmaker/educator accuracy review and Telugu language editing are also outstanding.

See `ROADMAP.md` and `CONTENT_ACCURACY_V08.md`.
