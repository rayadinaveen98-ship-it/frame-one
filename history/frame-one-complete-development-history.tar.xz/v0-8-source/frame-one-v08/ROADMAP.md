# Frame One — Product and Curriculum Roadmap (v0.8)

## Product promise
A short, simple, accurate and playful path from knowing nothing about filmmaking to planning and shooting a first scene. Learn the concepts by **seeing, comparing, trying and making**, not memorizing arbitrary artistic rules. We favour original illustrations and user-led experiments over copyright-dependent movie clip libraries.

## Progress: 23/33 lessons across 6 chapters

| Chapter | Available lessons (count) | Still planned |
| --- | --- | --- |
| 1 · Discover Cinema | Why We Watch; How Cinema Began; Frame/Shot/Scene; Genres; History of Indian Cinema (5) | None |
| 2 · Tell a Human Story | Story & Emotion; Screenplay; Acting; Character & Conflict; Dialogue (5) | Show, Don't Just Explain |
| 3 · Learn Visual Language | Shot Choices; Camera Placement; Lighting; Composition; Camera Movement; Lenses (6) | Colour on Screen |
| 4 · Sound & Editing | Sound; Editing; Dialogue and Ambience; Music (4) | Continuity; Rhythm & Transitions |
| 5 · People Behind a Film | Film Roles (1) | Indian 24-craft context; Writing/Camera/Art teamwork; Production & Post-production |
| 6 · Make Your First Film | First Film; Shot Lists (2) | Shoot One Scene; Edit a 60-second Story; Review and Improve |

**Total: 23 available, 10 remaining in the current teaching plan.** We may change the final total after user testing; no date is promised.

## Development phases

### v0.8 — currently delivered
- Ten new beginner lessons with clear explanatory sections, original choice activities, optional practice and checked quizzes.
- Additional on-page illustrated studies, Telugu helper summaries, glossary expansion and updated Sound unit filtering.
- Private local backup/export + validated restore to protect student work during prototype updates.
- Improved clarity about where an illustration is **not** a physical optics, lighting or camera-movement simulation.

### v0.8B — next focused batch
- Finish the ten remaining lessons in reviewed batches, prioritizing actual hands-on learning over volume.
- Add a visual colour-comparison exercise, continuity challenge, and simple sound/scene editing practice using original assets.
- Add **the Indian 24 crafts** with source-verifiable classification and distinction between departments/craft associations, crew roles and changes in small vs large productions.
- Improve Telugu coverage with native language review. Do not claim short summaries are complete translations.

### v0.9 — test on real devices
- Full interface review for keyboard, small screens, safe areas, reduced motion, contrast and screen reader.
- Offline/PWA installation, sound playback, file import/export and progress migration checks.
- Comprehension and usability study with 10–20 complete beginners; test for learning outcomes, not just app clicks.
- After a repo is chosen, version-controlled source, lint/test automation and packaging; consider a small Android testing build. iOS browser/PWA evaluation.

### v1.0 — only after meaningful validation
- Accurate full core course, polished visual interactions, privacy and copyright documentation, stable local data backup, and beginner-tested install workflow.
- No compulsory account, AI judgment of artistic quality, expensive subscriptions or unlicensed film content in initial release.

## Non-negotiables
- **Technically correct + plain language**, with a visible explanation of simplification.
- Artistic examples are possibilities, never universal emotional laws.
- Early Indian film history recognizes 1896 screenings and debated first-feature claims.
- Frame crop ≠ lens simulation; shot ≠ take; film soundtrack ≠ music alone; Telugu 24 crafts ≠ universal 24 job list.
- Local learning work stays private and exportable; downloads across origins do not automatically share browser storage.
