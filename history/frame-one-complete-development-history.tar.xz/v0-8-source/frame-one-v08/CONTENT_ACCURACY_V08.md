# Frame One v0.8 — Content Accuracy and Teaching Review

This review records checks made during development. It **does not** represent independent filmmaker, film historian or Telugu-language professional certification.

## New lessons: what to verify and avoid

| Area | Teaching rule |
| --- | --- |
| Genre | Genres overlap and descriptions evolve; fiction vs documentary are not always neatly separated. Documentaries still involve editorial decisions. |
| Indian cinema history | Early moving-picture exhibition in Bombay dates to **1896**. **Shree Pundalik (1912)** is part of the early-feature debate, and **Raja Harishchandra (1913)** is widely acknowledged as foundational. Avoid stating any uncontested 'first movie' without qualification. |
| Character and conflict | Conflict can be internal or external; not every film needs an antagonist or high-stakes conflict. |
| Dialogue | Speech, voice, action and silence can work together. Subtext is suggested meaning, not a mechanical formula. |
| Composition | Rule of thirds is an optional guideline. Negative space does not always equal loneliness. |
| Movement | Pan/tilt change direction from a position; tracking/dolly movement changes camera position. Effects depend on the scene. |
| Lenses | **Same sensor:** shorter focal length usually wider field of view. Camera position governs perspective relationships. Cropping the existing storyboard does not simulate a lens change or moving camera. |
| Ambience and dialogue | Environmental sound, music, dialogue and effects are different elements. Room tone may be recorded to aid editing. Clear location audio matters. |
| Film music | Diegetic music can be heard by characters in the story world. Emotional interpretations are not guaranteed. Obtain proper rights for any reused music. |
| Shot lists | Filming plans differ from the sequence of shots used in the final edit. Three shots are an illustration, not a rule. |

## References used for cross-checking

1. British Film Institute, *12 dazzling vintage film posters from the golden age of Indian cinema*. Discusses 1896 Bombay screenings and 1913 Raja Harishchandra: https://www.bfi.org.uk/features/indian-cinema-posters
2. Encyclopaedia of Indian Cinema, entries for Pundalik (1912) and Raja Harishchandra (1913): https://indiancine.ma/documents/DSP/Encyclopedia%2520of%2520Indian%2520Cinema.pdf
3. Adobe, *Different types of shots and camera angles in film*, for pan, tracking and dolly: https://www.adobe.com/in/creativecloud/video/production/cinematography/camera-shots-and-angles.html
4. Nikon, *Understanding focal length*, updated December 2025, lens focal length and angle of view: https://www.nikonusa.com/learn-and-explore/c/tips-and-techniques/understanding-focal-length

Sources are used for limited factual cross-checking; the lesson text is original and rewritten for beginners, not copied from those pages. General craft and art explanations are not represented as objectively correct emotional formulas.

## Test results and limitations

- Automated checks verify exactly 23 lesson objects, valid multiple-choice answer keys, 23 optional Telugu notes, interactive choice definitions, 6 chapter links, 35 glossary items, 10 visibly planned future topics, route/quiz behavior, and original lab regressions.
- Backup tests exercise malformed backup rejection, filtering unknown lesson IDs, bounding note lengths, escaping restored notes, and a valid export action.
- **Not yet tested:** complete real-device browser QA, visual screenshots of full app, precise audio playback on devices, accessible screen-reader flows, professional accuracy review, and native Telugu editing.
- No external movie clips/audio included. SVG/lab stages are **original illustrated educational sketches**, not motion-picture demonstrations or physics-based cinematography simulators.
