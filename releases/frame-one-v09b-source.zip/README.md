# Frame One — v0.9B source migration

33 drafted beginner lessons / six chapters / seven creative labs / 47 film words.

## Run in connected development environment

```sh
npm install
npm test
npm run build
npm run dev
```

This package includes React lessons + React chapters/glossary + a legacy compatibility module for home/labs/roles. `preview/` is an earlier working dependency-free static site, **not** a React preview. No package-lock because npm dependency downloads are unavailable here. Do not confuse the source-level tests with a successful production build.

Read `docs/MIGRATION_STATUS.md` for status and outstanding checks.
